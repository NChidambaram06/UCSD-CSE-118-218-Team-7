package com.example.gpswifiinfo

data class Event(
    val id: Long,
    val title: String,
    val startTime: Long,
    val endTime: Long,
    val description: String
)
