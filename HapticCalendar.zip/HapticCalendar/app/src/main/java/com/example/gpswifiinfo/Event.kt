package com.example.gpswifiinfo

data class Event(
    val calId: String,
    val id: Long,
    val title: String,
    val startTime: Long,
    val endTime: Long,
    val description: String
)
