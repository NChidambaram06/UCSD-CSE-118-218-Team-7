package com.example.gpswifiinfo

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.database.Cursor
import android.icu.util.TimeZone
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract
import android.util.Log
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AppCompatActivity
import java.util.Date

class MainActivity : AppCompatActivity() {
    private lateinit var calendarText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        calendarText = findViewById(R.id.calendarText)

        // Check for permission to read calendar events
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_CALENDAR
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Request permission if not granted
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CALENDAR),
                100
            )
        } else {
            // Load calendar events
            loadCalendarEvents()
        }

        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_CALENDAR
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Request permission if not granted
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.WRITE_CALENDAR),
                101
            )
        } else {
            // Add a sample event
            addSampleEvent()
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            loadCalendarEvents()
            addSampleEvent()
        }
    }


    private fun loadCalendarEvents() {
        val projection = arrayOf(
            CalendarContract.Events.TITLE,
            CalendarContract.Events.DTSTART,
            CalendarContract.Events.DTEND
        )

        val cursor: Cursor? = contentResolver.query(
            CalendarContract.Events.CONTENT_URI,
            projection,
            null,
            null,
            CalendarContract.Events.DTSTART + " ASC"
        )

        if (cursor == null || cursor.count == 0) {
            Log.d("MainActivity", "No events found or cursor is null")
            if (cursor != null) {
                Log.d("MainActivity", "Cursor count: ${cursor.count}")
            }
            calendarText.text = "No events found"
            return
        }

        cursor.use {
            val stringBuilder = StringBuilder()
            while (it.moveToNext()) {
                val title = it.getString(0)
                val startTime = it.getLong(1)
                stringBuilder.append("Event: $title\n")
            }
            Log.d("MainActivity", "Events loaded: $stringBuilder")
            calendarText.text = stringBuilder.toString()
        }
    }

    private fun addSampleEvent() {
        // Define a new event
        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, System.currentTimeMillis() + 60 * 60 * 1000) // Start time: 1 hour from now
            put(CalendarContract.Events.DTEND, System.currentTimeMillis() + 2 * 60 * 60 * 1000) // End time: 2 hours from now
            put(CalendarContract.Events.TITLE, "Sample Event")
            put(CalendarContract.Events.DESCRIPTION, "This is a sample event")
            put(CalendarContract.Events.CALENDAR_ID, getPrimaryCalendarId()) // The calendar ID where the event should be inserted
            put(CalendarContract.Events.EVENT_TIMEZONE, TimeZone.getDefault().id) // Time zone
        }

        // Insert the event into the calendar
        val uri = contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
        if (uri != null) {
            Log.d("MainActivity", "Sample event inserted with URI: $uri")

            // Fetch the inserted event details
            val eventDetails = getEventDetails(uri)
            Log.d("MainActivity", "Sample event: ${eventDetails.length}")
            calendarText.text = eventDetails
        } else {
            Log.d("MainActivity", "Failed to add sample event")
            calendarText.text = "Failed to add sample event."
        }
    }

    // Fetch event details using the URI
    @SuppressLint("Range")
    private fun getEventDetails(uri: Uri): String {
        val projection = arrayOf(
            CalendarContract.Events.TITLE,
            CalendarContract.Events.DTSTART,
            CalendarContract.Events.DTEND,
            CalendarContract.Events.DESCRIPTION
        )

        val cursor: Cursor? = contentResolver.query(
            uri,
            projection,
            null,
            null,
            null
        )

        val eventDetails = StringBuilder()
        cursor?.use {
            if (it.moveToFirst()) {
                Log.d("MainActivity", "Check 1")
                val title = it.getString(it.getColumnIndex(CalendarContract.Events.TITLE))
                val startTime = it.getLong(it.getColumnIndex(CalendarContract.Events.DTSTART))
                val endTime = it.getLong(it.getColumnIndex(CalendarContract.Events.DTEND))
                val description = it.getString(it.getColumnIndex(CalendarContract.Events.DESCRIPTION))

                eventDetails.append("Event: $title\n")
                eventDetails.append("Start: ${Date(startTime)}\n")
                eventDetails.append("End: ${Date(endTime)}\n")
                eventDetails.append("Description: $description\n")
                eventDetails.append("Check\n")
            }
        }

        return eventDetails.toString()
    }

    private fun getPrimaryCalendarId(): Long {
        var calendarId: Long = -1
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY)
        val cursor = contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            null,
            null,
            null
        )

        cursor?.use {
            while (it.moveToNext()) {
                val id = it.getLong(0)
                val isPrimary = it.getInt(1) > 0
                if (isPrimary) {
                    calendarId = id
                    break
                }
            }
        }

        if (calendarId == -1L) {
            // If no primary calendar is found, fall back to the first calendar
            calendarId = contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI,
                arrayOf(CalendarContract.Calendars._ID),
                null,
                null,
                null
            )?.use {
                if (it.moveToFirst()) it.getLong(0) else -1L
            } ?: -1L
        }

        return calendarId
    }


}
