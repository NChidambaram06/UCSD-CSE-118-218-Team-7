package com.example.gpswifiinfo

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Bundle
import android.provider.CalendarContract
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import java.util.*
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import com.google.api.client.extensions.android.http.AndroidHttp
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.json.jackson2.JacksonFactory
import com.google.api.services.calendar.CalendarScopes
import com.google.api.services.calendar.Calendar


class MainActivity : AppCompatActivity() {

    private lateinit var eventListAdapter: EventListAdapter
    private lateinit var recyclerView: RecyclerView
    private val eventList = mutableListOf<Event>()
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var calendarService: Calendar
    private val RC_SIGN_IN = 9001  // Unique request code for Google sign-in

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Configure Google Sign-In to request access to the user's Google Calendar
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(CalendarScopes.CALENDAR))
            .requestIdToken(getString(R.string.server_client_id)) // OAuth client ID from Google Cloud Console
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Sign-in the user (prompt if needed)
        val account = GoogleSignIn.getLastSignedInAccount(this)
        if (account != null && accountGrantedPermissions(account)) {
            setupCalendarService(account)
        } else {
            signIn()
        }

        // Initialize the RecyclerView and Adapter
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Set up the EventListAdapter
        eventListAdapter = EventListAdapter(eventList) { event ->
            showEventDetailsDialog(event)
        }
        recyclerView.adapter = eventListAdapter

        // Check for permission to read calendar events
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_CALENDAR
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Request permission if not granted
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CALENDAR),
                100
            )
        } else {
            // Load calendar events and create a sample event
            createSampleEvent()
            loadCalendarEvents()
        }

        // Add a sample event manually to the list for testing
        eventList.add(Event(1, "Event 1", System.currentTimeMillis() + 3000, System.currentTimeMillis() + 3600000, "Event Description"))
        eventListAdapter.notifyDataSetChanged()
        Log.d("EventList", "Event list size: ${eventList.size}")

        // Create a notification channel for Android 8.0 and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "event_notifications"
            val channelName = "Event Notifications"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, channelName, importance)
            channel.description = "Notifications for upcoming events"

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }

        // Start checking periodically for event times
        startCheckingEventTimes()
    }

    // Check if the necessary permissions are granted
    private fun accountGrantedPermissions(account: GoogleSignInAccount): Boolean {
        return GoogleSignIn.hasPermissions(account, Scope(CalendarScopes.CALENDAR))
    }

    private fun signIn() {
        val signInIntent = googleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)
                if (account != null) {
                    setupCalendarService(account)
                }
            } catch (e: ApiException) {
                Log.w("MainActivity", "Google sign in failed", e)
            }
        }
    }

    private fun setupCalendarService(account: GoogleSignInAccount) {
        val credential = GoogleAccountCredential.usingOAuth2(
            this, listOf(CalendarScopes.CALENDAR)
        )
        credential.selectedAccount = account.account

        calendarService = Calendar.Builder(
            AndroidHttp.newCompatibleTransport(),
            JacksonFactory.getDefaultInstance(),
            credential
        )
            .setApplicationName("Haptic Calendar")
            .build()
    }


    // Request permission results
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            createSampleEvent()
            loadCalendarEvents()
        }
    }

    // Create a sample event in the calendar
    private fun createSampleEvent() {
        Log.d("EventList", "Sample Event Made")
        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, System.currentTimeMillis() + 60 * 60 * 1000) // Start time: 1 hour from now
            put(CalendarContract.Events.DTEND, System.currentTimeMillis() + 2 * 60 * 60 * 1000) // End time: 2 hours from now
            put(CalendarContract.Events.TITLE, "Sample Event")
            put(CalendarContract.Events.DESCRIPTION, "This is a sample event")
            put(CalendarContract.Events.CALENDAR_ID, getPrimaryCalendarId()) // The calendar ID where the event should be inserted
            put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id) // Time zone
        }

        // Insert the event into the calendar
        val uri = contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
        if (uri != null) {
            Toast.makeText(this, "Sample event created", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Failed to create sample event", Toast.LENGTH_SHORT).show()
        }
    }

    // Fetch and load all calendar events
    @SuppressLint("Range")
    private fun loadCalendarEvents() {
        val projection = arrayOf(
            CalendarContract.Events._ID,
            CalendarContract.Events.TITLE,
            CalendarContract.Events.DTSTART,
            CalendarContract.Events.DTEND,
            CalendarContract.Events.DESCRIPTION
        )
        val cursor: Cursor? = contentResolver.query(
            CalendarContract.Events.CONTENT_URI,
            projection,
            null,
            null,
            CalendarContract.Events.DTSTART + " ASC"
        )

        cursor?.use {
            eventList.clear()  // Clear the current list
            while (it.moveToNext()) {
                val id = it.getLong(it.getColumnIndex(CalendarContract.Events._ID))
                val title = it.getString(it.getColumnIndex(CalendarContract.Events.TITLE))
                val startTime = it.getLong(it.getColumnIndex(CalendarContract.Events.DTSTART))
                val endTime = it.getLong(it.getColumnIndex(CalendarContract.Events.DTEND))
                val description = it.getString(it.getColumnIndex(CalendarContract.Events.DESCRIPTION))

                eventList.add(Event(id, title, startTime, endTime, description))
            }
            eventListAdapter.notifyDataSetChanged() // Update the RecyclerView
        }
    }

    // Show event details in a dialog when an item is clicked
    private fun showEventDetailsDialog(event: Event) {
        val details = """
            Title: ${event.title}
            Start Time: ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(java.util.Date(event.startTime))}
            End Time: ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(java.util.Date(event.endTime))}
            Description: ${event.description}
        """.trimIndent()

        val dialog = AlertDialog.Builder(this)
            .setTitle(event.title)
            .setMessage(details)
            .setPositiveButton("OK", null)
            .create()
        dialog.show()
    }

    // Helper function to get primary calendar ID
    private fun getPrimaryCalendarId(): Long {
        var calendarId: Long = -1
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY)
        val cursor = contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            null,
            null,
            null
        )

        cursor?.use {
            while (it.moveToNext()) {
                val id = it.getLong(0)
                val isPrimary = it.getInt(1) > 0
                if (isPrimary) {
                    calendarId = id
                    break
                }
            }
        }

        if (calendarId == -1L) {
            // If no primary calendar is found, fall back to the first calendar
            calendarId = contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI,
                arrayOf(CalendarContract.Calendars._ID),
                null,
                null,
                null
            )?.use {
                if (it.moveToFirst()) it.getLong(0) else -1L
            } ?: -1L
        }

        return calendarId
    }

    // Method to make the watch buzz
    private fun buzzWatch(eventTitle: String) {
        // Vibrate the watch
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Vibrate for 500 milliseconds with the default amplitude
            val vibrationEffect = VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE)
            vibrator.vibrate(vibrationEffect)
        } else {
            // For older devices, use the deprecated method
            vibrator.vibrate(500)
        }
        Toast.makeText(this, "Event time reached! Buzzing...", Toast.LENGTH_SHORT).show()

        // Send a notification to the watch
        sendNotification(eventTitle)
    }

    private fun sendNotification(eventTitle: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "event_notifications"

        // Create the notification content
        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.splash_icon) // Use an appropriate icon
            .setContentTitle("Event Reminder")
            .setContentText("It's time for your event: $eventTitle")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true) // Dismiss the notification when clicked

        // Display the notification
        notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
    }

    private fun checkEventTime() {
        val currentTime = System.currentTimeMillis()
        for (event in eventList) {
            if (isTimeClose(currentTime, event.startTime)) {
                buzzWatch(event.title)  // Pass the event title to show in the notification
            }
        }
    }

    // Helper method to check if the current time is close to the event start time
    private fun isTimeClose(currentTime: Long, eventTime: Long): Boolean {
        val difference = Math.abs(currentTime - eventTime)
        val timeThreshold = 60 * 1000  // Set a threshold of 1 minute (60,000 milliseconds)
        return difference <= timeThreshold
    }

    // Schedule periodic checks for event times
    private fun startCheckingEventTimes() {
        val handler = Handler(Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                checkEventTime()  // Check if any event time matches the current time
                handler.postDelayed(this, 60 * 1000)  // Re-check every minute
            }
        }
        handler.post(runnable)
    }
}
