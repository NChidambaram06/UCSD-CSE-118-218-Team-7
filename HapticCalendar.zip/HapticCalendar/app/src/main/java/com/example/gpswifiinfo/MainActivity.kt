package com.example.gpswifiinfo

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Bundle
import android.provider.CalendarContract
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var eventListAdapter: EventListAdapter
    private lateinit var recyclerView: RecyclerView
    private val eventList = mutableListOf<Event>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the RecyclerView and Adapter
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Set up the EventListAdapter
        eventListAdapter = EventListAdapter(eventList) { event ->
            showEventDetailsDialog(event)
        }
        recyclerView.adapter = eventListAdapter

        // Check for permission to read calendar events
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_CALENDAR
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Request permission if not granted
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_CALENDAR),
                100
            )
        } else {
            // Load calendar events and create a sample event
            createSampleEvent()
            loadCalendarEvents()
        }
        eventList.add(Event(1, "Event 1", System.currentTimeMillis(), System.currentTimeMillis() + 3600000, "Event Description"))
        eventListAdapter.notifyDataSetChanged()
        Log.d("EventList", "Event list size: ${eventList.size}")

    }

    // Request permission results
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            createSampleEvent()
            loadCalendarEvents()
        }
    }

    // Create a sample event in the calendar
    private fun createSampleEvent() {
        Log.d("EventList", "Sample Event Made")
        val values = ContentValues().apply {
            put(CalendarContract.Events.DTSTART, System.currentTimeMillis() + 60 * 60 * 1000) // Start time: 1 hour from now
            put(CalendarContract.Events.DTEND, System.currentTimeMillis() + 2 * 60 * 60 * 1000) // End time: 2 hours from now
            put(CalendarContract.Events.TITLE, "Sample Event")
            put(CalendarContract.Events.DESCRIPTION, "This is a sample event")
            put(CalendarContract.Events.CALENDAR_ID, getPrimaryCalendarId()) // The calendar ID where the event should be inserted
            put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id) // Time zone
        }

        // Insert the event into the calendar
        val uri = contentResolver.insert(CalendarContract.Events.CONTENT_URI, values)
        if (uri != null) {
            Toast.makeText(this, "Sample event created", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Failed to create sample event", Toast.LENGTH_SHORT).show()
        }
    }

    // Fetch and load all calendar events
    @SuppressLint("Range")
    private fun loadCalendarEvents() {
        val projection = arrayOf(
            CalendarContract.Events._ID,
            CalendarContract.Events.TITLE,
            CalendarContract.Events.DTSTART,
            CalendarContract.Events.DTEND,
            CalendarContract.Events.DESCRIPTION
        )
        val cursor: Cursor? = contentResolver.query(
            CalendarContract.Events.CONTENT_URI,
            projection,
            null,
            null,
            CalendarContract.Events.DTSTART + " ASC"
        )

        cursor?.use {
            eventList.clear()  // Clear the current list
            while (it.moveToNext()) {
                val id = it.getLong(it.getColumnIndex(CalendarContract.Events._ID))
                val title = it.getString(it.getColumnIndex(CalendarContract.Events.TITLE))
                val startTime = it.getLong(it.getColumnIndex(CalendarContract.Events.DTSTART))
                val endTime = it.getLong(it.getColumnIndex(CalendarContract.Events.DTEND))
                val description = it.getString(it.getColumnIndex(CalendarContract.Events.DESCRIPTION))

                eventList.add(Event(id, title, startTime, endTime, description))
            }
            eventListAdapter.notifyDataSetChanged() // Update the RecyclerView
        }
    }

    // Show event details in a dialog when an item is clicked
    private fun showEventDetailsDialog(event: Event) {
        val details = """
            Title: ${event.title}
            Start Time: ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(java.util.Date(event.startTime))}
            End Time: ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(java.util.Date(event.endTime))}
            Description: ${event.description}
        """.trimIndent()

        val dialog = AlertDialog.Builder(this)
            .setTitle(event.title)
            .setMessage(details)
            .setPositiveButton("OK", null)
            .create()
        dialog.show()
    }

    // Helper function to get primary calendar ID
    private fun getPrimaryCalendarId(): Long {
        var calendarId: Long = -1
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY)
        val cursor = contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            null,
            null,
            null
        )

        cursor?.use {
            while (it.moveToNext()) {
                val id = it.getLong(0)
                val isPrimary = it.getInt(1) > 0
                if (isPrimary) {
                    calendarId = id
                    break
                }
            }
        }

        if (calendarId == -1L) {
            // If no primary calendar is found, fall back to the first calendar
            calendarId = contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI,
                arrayOf(CalendarContract.Calendars._ID),
                null,
                null,
                null
            )?.use {
                if (it.moveToFirst()) it.getLong(0) else -1L
            } ?: -1L
        }

        return calendarId
    }
}
