package com.example.gpswifiinfo

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.ContentValues.TAG
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Bundle
import android.provider.CalendarContract
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import java.util.*
import android.os.Handler
import android.os.Looper
import android.widget.Button
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationCompat
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Task
import com.google.api.client.extensions.android.http.AndroidHttp
import com.google.api.client.googleapis.extensions.android.gms.auth.GoogleAccountCredential
import com.google.api.client.json.jackson2.JacksonFactory
import com.google.api.services.calendar.CalendarScopes
import com.google.api.services.calendar.Calendar


class MainActivity : AppCompatActivity() {

    private lateinit var eventListAdapter: EventListAdapter
    private lateinit var recyclerView: RecyclerView
    private val eventList = mutableListOf<Event>()
    private lateinit var googleSignInClient: GoogleSignInClient
    private lateinit var calendarService: Calendar
    private lateinit var signInLauncher: ActivityResultLauncher<Intent>
    private val RC_SIGN_IN = 9001  // Unique request code for Google sign-in

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Configure Google Sign-In to request access to the user's Google Calendar
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestScopes(Scope(CalendarScopes.CALENDAR))
//            .requestIdToken("441424336052-c7ku9nuvfsahqas3hvm5t0oudmuooph2.apps.googleusercontent.com") // OAuth client ID from Google Cloud Console
            .build()

        googleSignInClient = GoogleSignIn.getClient(this, gso)

        // Initialize the sign-in launcher
        signInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            Log.d("SignInActivity", "sign in launcher")
            if (result.resultCode == Activity.RESULT_OK) {
                Log.d("SignInActivity", "Sign-in succeeded. ${result.resultCode} | ${Activity.RESULT_OK}")
                val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
                handleSignInResult(task)
            } else if (result.resultCode == Activity.RESULT_CANCELED) {
                Log.d("SignInActivity", "Sign-in was canceled by the user. ${result.resultCode} | ${Activity.RESULT_CANCELED}")
                signIn()
            } else {
                Log.d("SignInActivity", "Sign-in failed. ${result.resultCode} | ${Activity.RESULT_OK}")
            }
        }

        // Use the currently signed-in Google account
        val account = GoogleSignIn.getLastSignedInAccount(this)
        if (account != null && accountGrantedPermissions(account)) {
            setupCalendarService(account)
            loadCalendarEvents()  // Automatically load calendar events if an account is already signed in
        } else {
            Log.d("MainActivity", "No signed-in account found")
            // If no account is signed in, proceed with sign-in
            signIn()
        }

        // Initialize the RecyclerView and Adapter
        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Set up the EventListAdapter
        eventListAdapter = EventListAdapter(eventList) { event ->
            showEventDetailsDialog(event)
        }
        recyclerView.adapter = eventListAdapter

        // Request permission to read calendar events if not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            Log.d("SignInActivity", "${Manifest.permission.READ_CALENDAR} | ${PackageManager.PERMISSION_GRANTED}")
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CALENDAR), 100)
        } else {
            Log.d("SignInActivity", "permission")
            Log.d("SignInActivity", "${ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR)} | ${PackageManager.PERMISSION_GRANTED}")
            Log.d("SignInActivity", "account: ${account}")
//            if (account == null) {
//                signIn()
//            }
            loadCalendarEvents()
        }

        // Create a notification channel for Android 8.0 and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "event_notifications"
            val channelName = "Event Notifications"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(channelId, channelName, importance)
            channel.description = "Notifications for upcoming events"

            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }

        // Start checking periodically for event times
        startCheckingEventTimes()
    }

    // Check if the necessary permissions are granted
    private fun accountGrantedPermissions(account: GoogleSignInAccount): Boolean {
        return GoogleSignIn.hasPermissions(account, Scope(CalendarScopes.CALENDAR))
    }

    private fun signIn() {
        val signInIntent = googleSignInClient.signInIntent
        Log.d("SignInActivity", "Signing In - ${signInIntent}")
        signInLauncher.launch(signInIntent)
    }

    // Handle the result of Google Sign-In
    private fun handleSignInResult(completedTask: Task<GoogleSignInAccount>) {
        try {
            val account = completedTask.getResult(ApiException::class.java)
            Log.d("SignInActivity", "Sign-in successful!")
            Log.d("SignInActivity", "account: ${account.email}")
            setupCalendarService(account)
            loadCalendarEvents()  // Load calendar events after successful sign-in
        } catch (e: ApiException) {
            Log.d("SignInActivity", "signInResult: failed code=" + e.statusCode)
        }
    }

    private fun setupCalendarService(account: GoogleSignInAccount) {
        val credential = GoogleAccountCredential.usingOAuth2(
            this, listOf(CalendarScopes.CALENDAR)
        )
        credential.selectedAccount = account.account

        calendarService = Calendar.Builder(
            AndroidHttp.newCompatibleTransport(),
            JacksonFactory.getDefaultInstance(),
            credential
        )
            .setApplicationName("Haptic Calendar")
            .build()
    }

    // Request permission results
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Log.d("SignInActivity", "Calendar permission granted")
            loadCalendarEvents()
        }
    }

    // Fetch and load all calendar events
    @SuppressLint("Range")
    private fun loadCalendarEvents() {
        Log.d("SignInActivity", "loading calendar events")
        val projection = arrayOf(
            CalendarContract.Events.CALENDAR_ID,
            CalendarContract.Events._ID,
            CalendarContract.Events.TITLE,
            CalendarContract.Events.DTSTART,
            CalendarContract.Events.DTEND,
            CalendarContract.Events.DESCRIPTION,
        )
        Log.d("SignInActivity", "${CalendarContract.Events.TITLE}")
        Log.d("SignInActivity", "projection: ${projection}")
        val cursor: Cursor? = contentResolver.query(
            CalendarContract.Events.CONTENT_URI,
            projection,
            null,
            null,
            CalendarContract.Events.DTSTART + " ASC"
        )
        Log.d("SignInActivity", "cursor: ${cursor}")

        cursor?.use {
            eventList.clear()  // Clear the current list
            Log.d("SignInActivity", "eventlist: ${eventList}")
            eventList.add(Event("Events", 1111, "Test Event 1", System.currentTimeMillis() + 75 * 1000, System.currentTimeMillis() + 60 * 60 * 1000, "manually add in event for testing"))
            eventList.add(Event("alexa-testing", 2222, "Test Event 2", System.currentTimeMillis(), System.currentTimeMillis() + 60 * 60 * 1000, "manually add in event for testing importance"))
            Log.d("SignInActivity", "eventlist: ${eventList}")
            Log.d("SignInActivity", "num events: ${it.count}")
            var numEvents = eventList.size-1
            while (numEvents >= 0) {
//            while (it.moveToNext()) {
                eventList[numEvents]
                Log.d("SignInActivity", "event: ${eventList[numEvents]}")
//                val id = it.getLong(it.getColumnIndex(CalendarContract.Events._ID))
//                val title = it.getString(it.getColumnIndex(CalendarContract.Events.TITLE))
//                val startTime = it.getLong(it.getColumnIndex(CalendarContract.Events.DTSTART))
//                val endTime = it.getLong(it.getColumnIndex(CalendarContract.Events.DTEND))
//                val description = it.getString(it.getColumnIndex(CalendarContract.Events.DESCRIPTION))
                val calId = eventList[numEvents].calId
                val id = eventList[numEvents].id
                val title = eventList[numEvents].title
                val startTime = eventList[numEvents].startTime
                val endTime = eventList[numEvents].endTime
                val description = eventList[numEvents].description

                Log.d("SignInActivity", "Event data: ${calId} | ${id} | ${title} | ${startTime} | ${endTime} | ${description}")
                eventList.add(Event(calId, id, title, startTime, endTime, description))
                Log.d("SignInActivity", "eventlist: ${eventList}")
                numEvents -= 1
            }
            Log.d("SignInActivity", "eventlist: ${eventList}")
            eventListAdapter.notifyDataSetChanged() // Update the RecyclerView
        }
    }

    // Show event details in a dialog when an item is clicked
    private fun showEventDetailsDialog(event: Event) {
        val details = """
            Title: ${event.title}
            Start Time: ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(java.util.Date(event.startTime))} 
            End Time: ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(java.util.Date(event.endTime))}
            Description: ${event.description}
        """.trimIndent()

        val dialog = AlertDialog.Builder(this)
            .setTitle(event.title)
            .setMessage(details)
            .setPositiveButton("OK", null)
            .create()
        dialog.show()
    }

    // Helper function to get primary calendar ID
    private fun getPrimaryCalendarId(): Long {
        var calendarId: Long = -1
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.IS_PRIMARY)
        val cursor = contentResolver.query(
            CalendarContract.Calendars.CONTENT_URI,
            projection,
            null,
            null,
            null
        )

        cursor?.use {
            while (it.moveToNext()) {
                val id = it.getLong(0)
                val isPrimary = it.getInt(1) > 0
                if (isPrimary) {
                    calendarId = id
                    break
                }
            }
        }

        if (calendarId == -1L) {
            // If no primary calendar is found, fall back to the first calendar
            calendarId = contentResolver.query(
                CalendarContract.Calendars.CONTENT_URI,
                arrayOf(CalendarContract.Calendars._ID),
                null,
                null,
                null
            )?.use {
                if (it.moveToFirst()) it.getLong(0) else -1L
            } ?: -1L
        }

        return calendarId
    }

    // Method to make the watch buzz
    private fun buzzWatch(eventTitle: String, calId: String) {
        // Vibrate the watch
        Log.d("Events", "buzzing")
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (calId == "alexa-testing") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Vibrate for 500 milliseconds with the default amplitude
                Log.d("Events", "bigger buzz")
                val vibrationEffect = VibrationEffect.createOneShot(750, VibrationEffect.DEFAULT_AMPLITUDE)
                Log.d("Events", "test 1")
                vibrator.vibrate(vibrationEffect)
                Log.d("Events", "test 2")
                Handler(Looper.getMainLooper()).postDelayed({
                    vibrator.vibrate(vibrationEffect)
                }, 800) // Delay between buzzes
                Handler(Looper.getMainLooper()).postDelayed({
                    vibrator.vibrate(vibrationEffect)
                }, 1600) // Delay between buzzes
            } else {
                // For older devices, use the deprecated method
                vibrator.vibrate(750)
            }
        } else{
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Vibrate for 500 milliseconds with the default amplitude
                val vibrationEffect = VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE)
                vibrator.vibrate(vibrationEffect)
            } else {
                // For older devices, use the deprecated method
                vibrator.vibrate(500)
            }
        }
        Log.d("Events", "test 3")
        Toast.makeText(this, "Event time reached! Buzzing...", Toast.LENGTH_SHORT).show()
        Log.d("Events", "test 4")
        // Send a notification to the watch
        sendNotification(eventTitle)
    }

    private fun sendNotification(eventTitle: String) {
        Log.d("Events", "Notification for ${eventTitle}")
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "event_notifications"

        // Create the notification content
        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.splash_icon) // Use an appropriate icon
            .setContentTitle("Event Reminder")
            .setContentText("It's time for your event: $eventTitle")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true) // Dismiss the notification when clicked

        // Display the notification
        notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
    }

    private fun checkEventTime() {
        val currentTime = System.currentTimeMillis()
        for (event in eventList) {
            if (isTimeClose(currentTime, event.startTime)) {
                Log.d("Events", "starting event: ${event}")
                buzzWatch(event.title, event.calId)  // Pass the event title to show in the notification
            }
        }
    }

    // Helper method to check if the current time is close to the event start time
    private fun isTimeClose(currentTime: Long, eventTime: Long): Boolean {
        val difference = Math.abs(currentTime - eventTime)
        val timeThreshold = 60 * 1000  // Set a threshold of 1 minute (60,000 milliseconds)
        return difference <= timeThreshold
    }

    // Schedule periodic checks for event times
    private fun startCheckingEventTimes() {
        Log.d("MainActivity", "Start Ticker")
        val handler = Handler(Looper.getMainLooper())
        val runnable = object : Runnable {
            override fun run() {
                Log.d("MainActivity", "Tick")
                checkEventTime()  // Check if any event time matches the current time
                handler.postDelayed(this, 10 * 1000)  // Re-check every minute
            }
        }
        handler.post(runnable)
    }
}
